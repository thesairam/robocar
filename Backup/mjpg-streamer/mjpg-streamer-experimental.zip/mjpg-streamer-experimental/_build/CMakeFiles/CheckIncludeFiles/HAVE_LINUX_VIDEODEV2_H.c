/* */
#include <linux/videodev2.h>


int main(void){return 0;}

