/* */
#include <sys/inotify.h>


int main(void){return 0;}

